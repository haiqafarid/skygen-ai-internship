# Willow & Sage — Brand Brief

## Brand concept
Willow & Sage is a fictional natural skincare brand created for an AI-assisted image and content workflow project. The brand concept communicates calm self-care, botanical simplicity, freshness, and a gentle premium feel.

## Audience
People interested in skincare, simple self-care routines, botanical-inspired visuals, and a calm, natural brand presentation. This is a conceptual audience for the project, not research-backed customer segmentation.

## Visual direction
- **Mood:** calm, fresh, natural, clean, reassuring.
- **Palette:** sage green, warm cream, soft beige, botanical green, and restrained earthy neutrals.
- **Lighting:** soft daylight and warm, diffused light.
- **Composition:** clear focal subject, uncluttered backgrounds, balanced framing, natural botanical accents.
- **Image themes:** skincare products, product flat lays, skincare routines, natural ingredients, wellness moments, and nature inspiration.
- **Typography/brand presentation:** understated, legible, and minimal where typography is used.

## Voice and copy direction
Use clear, warm, simple, reassuring language. Avoid exaggerated promises, medical claims, or statements about efficacy, ingredients, certifications, or test results unless independently verified.

## Intended use
The visual assets are concept materials for an educational workflow demonstration. The brand and product names are fictional; generated packaging and labels should not be treated as verified real-world product information.

## Creative success criteria
1. A consistent natural skincare mood across the image collection.
2. Clear subject focus and readable composition.
3. Prompts and revisions documented transparently.
4. Human review of visual and written outputs.
5. Clear distinction between generated concept assets, actual manual edits, and illustrative boards.
