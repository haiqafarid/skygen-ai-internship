# Willow & Sage — Project 02 Final Submission Pack

This ZIP contains the project deliverables only, organized by assignment requirement. The irrelevant user-provided laptop/reference image and extra illustrative collage files have been excluded. The requested three-image iteration board is included by itself in `04_Iteration_Evidence`.

## Contents
1. Brand brief
2. Twelve individual AI concept images and a contact sheet
3. Prompt and copy log workbook
4. Three-image iteration comparison board, three separate cropped comparison images, and matching prompt notes
5. Four original/edited image pairs, before/after comparisons, and edit record
6. Copywriting tracker
7. 30-second silent promotional video draft
8. Seven-page workflow and limitations report
9. AI disclosure and third-party asset credits

## Important accuracy note
The three-image iteration board is a prepared comparison visual; the original generation history/tool metadata is not independently verified for every image. The video is silent and still needs your voiceover if audio narration is required. The workbooks no longer contain bracketed “enter/paste” instructions. Where actual generation metadata was unavailable, it is clearly marked “Not recorded in the available project files” rather than guessed. The three iteration prompts now match the included iteration board.
