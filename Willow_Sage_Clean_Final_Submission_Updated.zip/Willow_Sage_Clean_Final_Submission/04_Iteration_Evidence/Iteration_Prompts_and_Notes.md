# Three Image Iterations — Prompt and Evidence Log

The prompts below are transcribed from the included three-image iteration board. The comparison images are cropped from that board and stored individually in `Individual_Iterations/`. The board itself is retained as the overview. Tool/version, generation dates, and settings are not recorded in the available project files, so they are not guessed.

## Iteration 1: Product Jar — Willow & Sage Hydrating Face Cream

**Original prompt**
> A natural skincare product jar with wooden lid, Willow & Sage brand, surrounded by green leaves and white flowers, on a stone surface.

**Revised prompt**
> High-quality, natural light product photo of a Willow & Sage hydrating face cream jar with a wooden lid, placed on a stone surface, surrounded by fresh green leaves and white flowers, soft sunlight, clean background, sharp focus, professional and minimal styling.

**Comparison image:** `Individual_Iterations/Iteration_1_Product_Jar_Comparison.png`

**Observed visual difference:** The final panel shows brighter natural lighting, a cleaner background, sharper product focus and a clearer label, with fresher colors.

**Tool/version, date, and settings:** Not recorded in the available project files.

## Iteration 2: Serum Bottle — Willow & Sage Radiant Face Serum

**Original prompt**
> A glass bottle of face serum with dropper, Willow & Sage label, surrounded by green leaves and white flowers, natural background.

**Revised prompt**
> Studio-style, natural light image of a Willow & Sage Radiant Face Serum bottle with dropper, centered composition, clear and sharp label, surrounded by fresh green leaves and white flowers, soft sunlight, clean and minimal background, professional product photography.

**Comparison image:** `Individual_Iterations/Iteration_2_Serum_Bottle_Comparison.png`

**Observed visual difference:** The final panel shows a more centered composition, sharper details and label, improved color balance and contrast, and a cleaner product-photo look.

**Tool/version, date, and settings:** Not recorded in the available project files.

## Iteration 3: Lifestyle Image — Woman Using Face Mask

**Original prompt**
> A woman with a green face mask, towel on her head, relaxing, natural background, skincare lifestyle photo.

**Revised prompt**
> Natural, warm daylight lifestyle photo of a woman applying a green face mask, towel wrapped around her head, eyes closed, soft and realistic skin texture, minimal and natural background with plants, clean and calming aesthetic, professional look.

**Comparison image:** `Individual_Iterations/Iteration_3_Face_Mask_Lifestyle_Comparison.png`

**Observed visual difference:** The final panel shows warmer natural lighting, more realistic-looking skin texture, a cleaner and simpler background, and a calmer overall aesthetic.

**Tool/version, date, and settings:** Not recorded in the available project files.

## Evidence note

These prompts and comparisons match the supplied iteration board. The available files do not independently establish the original generation session metadata. Do not present unrecorded tool/version/date/settings as verified facts.