# Manual Image Edit Evidence

Four original/edited image pairs are included. Each edit was applied to the image file using standard image adjustments; the exact adjustment factors are recorded for transparency. These are image adjustments, not edits to product facts or claims.

| Pair | Original | Edited file | Changes made |
|---|---|---|---|
| EDIT_01 | `Originals/01_hero_product_shot.png` | `Edited/EDIT_01_edited.jpg` | Slightly increased brightness and contrast for a clearer product focal point. Brightness 1.08; contrast 1.10; sharpness 1.08. Before/after comparison: `EDIT_01_before_after.jpg`. |
| EDIT_02 | `Originals/03_natural_ingredients.png` | `Edited/EDIT_02_edited.jpg` | Increased color saturation modestly and sharpened details to emphasize ingredient textures. Contrast 1.04; saturation 1.12; sharpness 1.22. Before/after comparison: `EDIT_02_before_after.jpg`. |
| EDIT_03 | `Originals/05_product_flatlay.png` | `Edited/EDIT_03_edited.jpg` | Adjusted brightness and contrast to improve separation between the product and background. Brightness 1.06; contrast 1.12; sharpness 1.08. Before/after comparison: `EDIT_03_before_after.jpg`. |
| EDIT_04 | `Originals/08_product_detail.png` | `Edited/EDIT_04_edited.jpg` | Applied mild sharpening and a small contrast increase to improve visible product detail. Contrast 1.08; sharpness 1.25. Before/after comparison: `EDIT_04_before_after.jpg`. |
