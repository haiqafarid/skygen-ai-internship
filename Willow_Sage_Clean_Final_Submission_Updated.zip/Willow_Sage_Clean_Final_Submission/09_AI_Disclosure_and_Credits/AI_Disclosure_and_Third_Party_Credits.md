# AI Disclosure and Third-Party Asset Credits

## AI disclosure
This educational project uses AI-assisted concept development, image generation, and draft copywriting for the fictional Willow & Sage natural skincare brand. Generated outputs are concept assets and may contain visual artifacts or inaccurate product-label text. Human review is required before use. Prompt records and iteration notes in this pack distinguish documented prompt text from evidence that still needs verification.

## Human contribution
The project workflow includes brand-direction planning, prompt drafting and refinement, selection/review of visual concepts, copy review, organization of project files, and preparation of workflow documentation. Only claim manual image edits, final exports, or generation sessions that were actually performed and can be evidenced.

## Third-party asset credits
No third-party stock photo, music, or font license records were provided with the materials used to assemble this pack. The included concept visuals were generated for this project or provided as a project reference. If you add external images, music, fonts, templates, or other assets to the video or final package, record the asset title, creator/provider, source URL, license/permission, and access date here before submission.

## Tool and model disclosure
Exact generation tool/version and settings were not verifiable from the supplied materials for every individual image. Do not infer or invent them. Record the actual tool, version/model, settings, and date from your generation history when available; otherwise state “not available in the tool interface.”

## Fictional-brand note
Willow & Sage and the skincare product concepts are fictional. Generated labels, ingredients, benefits, certifications, and product claims are not verified product facts.
